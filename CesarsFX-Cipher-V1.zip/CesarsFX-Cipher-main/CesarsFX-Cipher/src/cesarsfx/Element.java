package cesarsfx;

public class Element {
	public int zahl;
	public String buchstabe;
	
	public Element(int zahl,String buchstabe) {
		this.zahl=zahl;
		this.buchstabe=buchstabe;
	}

}
