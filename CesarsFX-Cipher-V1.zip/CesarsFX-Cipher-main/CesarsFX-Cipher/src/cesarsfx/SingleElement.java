package cesarsfx;

public class SingleElement {
	public int zahl;
	public char buchstabe;
	
	public SingleElement(int zahl, char buchstabe) {
		this.zahl=zahl;
		this.buchstabe=buchstabe;
	}

}
