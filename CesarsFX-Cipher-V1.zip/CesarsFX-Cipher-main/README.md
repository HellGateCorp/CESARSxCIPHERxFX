![C-FX](https://user-images.githubusercontent.com/83019866/119243198-e818df80-bb64-11eb-96fe-7cd89e5149eb.png)
![C-FX2](https://user-images.githubusercontent.com/83019866/119243199-e818df80-bb64-11eb-8f7c-5a09e4dd6488.png)
![C-FX3](https://user-images.githubusercontent.com/83019866/119243200-e8b17600-bb64-11eb-8d15-9db514a60370.png)
# CesarsFX-Cipher

A JavaFX based crossplatformed Application that transform your given inputed Ciphers from Arabic(0-9) to Roma(IXC) Token or backwards, powered by an unique magical Algorithm. 🏛🕌🔮
#finalexcam100/100
